setwd("C:\\Users\\rsf06\\OneDrive\\Desktop\\IT24103928(Lab09)")

x<-rnorm(25,mean=45,sd=2)
t.test(x,mu=46,alternative="less")