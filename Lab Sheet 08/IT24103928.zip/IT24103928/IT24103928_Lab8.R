##Setting the directory
setwd("C:\\Users\\rsf06\\OneDrive\\Desktop\\IT24103928")

##Importing the data set
data<-read.table("Exercise - LaptopsWeights.txt",header=TRUE)
fix(data)
attach(data)

##Question 01
#Commands "mean" & "sd" will compute the mean and standard deviation for data.
popmean<-mean(Weight.kg.)
popsd<-sd(Weight.kg.)

##Question 02
#First create null vectors to store sample data sets.
samples<<-c()
n<<-c()
#The "for" loop will be used to create and assign samples of size 6 for "samples" variable created above.
#Using "sample" command we can draw a random sample either with replacement or without replacement.
#By making "replace" argument as TRUE we can create samples with replacement.
for(i in 1:25){
  s<-sample(Weight.kg.,6,replace=TRUE)
  samples<-cbind(samples,s)
  n<<-c(n,paste('S',i,sep=''))
}

#Assign column names for each sample created. Names have stored earlier under "n" variable.
colnames(samples)=n
#Using "apply" command we can ask to calculate any function such as mean, sd, etc. row wise or
#column wise in a matrix.
#Here, considering the second argument as "2" we can calculate either mean/sd column wise
#which stored earlier in "samples" variable which is a matrix.
s.means<-apply(samples,2,mean)
s.sds<-apply(samples,2,sd)

##Question 03
#Following commands will calculate mean and standard deviation of sample means stored in "s.means" variable.
mean.of.means<-mean(s.means)
sd.of.means<-sd(s.means)

#Compare and state relationships
popmean
mean.of.means
popsd
sd.of.means
popsd/sqrt(6)